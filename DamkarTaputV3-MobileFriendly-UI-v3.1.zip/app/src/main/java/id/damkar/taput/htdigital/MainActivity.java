package id.damkar.taput.htdigital;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.util.*;

public class MainActivity extends Activity {
    private static final String MOB = "+6285296150410";
    private static final String OFF = "063321113";

    private SharedPreferences pref;
    private LinearLayout root;
    private TextView statusTv, reguTv;
    private Handler sliderHandler = new Handler();
    private int slideIndex = 0;

    private final String[] REGU = {
        "Regu 1 - Pos Damkar Tarutung","Regu 2 - Pos Damkar Tarutung","Regu 3 - Pos Damkar Tarutung",
        "Regu 1 - Pos Damkar Siborong-borong","Regu 2 - Pos Damkar Siborong-borong","Regu 3 - Pos Damkar Siborong-borong",
        "Regu 1 - Pos Damkar Pahae","Regu 2 - Pos Damkar Pahae","Regu 3 - Pos Damkar Pahae",
        "Regu 1 - Pos Damkar Pangaribuan","Regu 2 - Pos Damkar Pangaribuan","Regu 3 - Pos Damkar Pangaribuan"
    };

    private final String[] NEWS_TITLE = {
        "Siaga & Pelayanan Damkar Taput",
        "Kesiapsiagaan Personel",
        "Edukasi Pencegahan Kebakaran"
    };
    private final String[] NEWS_BODY = {
        "Informasi pelayanan dan kesiapsiagaan Damkar Tapanuli Utara.",
        "Personel siap menerima laporan dan melaksanakan penanganan darurat.",
        "Kenali bahaya kebakaran dan gunakan APAR dengan benar."
    };
    private final int[] NEWS_IMAGES = {
        R.drawable.news_1, R.drawable.news_2, R.drawable.news_3
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        pref = getSharedPreferences("damkar", MODE_PRIVATE);
        showEntry();
    }

    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable bg(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        return g;
    }

    private TextView text(String value, float size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setIncludeFontPadding(false);
        return t;
    }

    private void base() {
        sliderHandler.removeCallbacksAndMessages(null);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(0xFFF5F7FA);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setPadding(0, 0, 0, dp(18));
        scroll.addView(page);

        root = page;
        setContentView(scroll);
    }

    private View topBar(String title, String subtitle) {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.VERTICAL);
        bar.setGravity(Gravity.CENTER);
        bar.setPadding(dp(20), dp(18), dp(20), dp(18));
        bar.setBackgroundColor(0xFFC62828);

        TextView t = text(title, 25, Color.WHITE);
        t.setTypeface(null, 1);
        t.setGravity(Gravity.CENTER);

        TextView s = text(subtitle, 12.5f, 0xFFFFE9E9);
        s.setGravity(Gravity.CENTER);
        s.setPadding(0, dp(6), 0, 0);

        bar.addView(t, new LinearLayout.LayoutParams(-1, -2));
        bar.addView(s, new LinearLayout.LayoutParams(-1, -2));
        return bar;
    }

    private TextView sectionLabel(String value) {
        TextView t = text(value, 12, 0xFF607D8B);
        t.setTypeface(null, 1);
        t.setLetterSpacing(0.05f);
        t.setPadding(dp(4), dp(16), dp(4), dp(8));
        return t;
    }

    private Button actionButton(String label, int fill, int textColor) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(15.5f);
        b.setTextColor(textColor);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(14), 0, dp(14), 0);
        b.setBackground(bg(fill, 14));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(54));
        p.setMargins(dp(16), dp(5), dp(16), dp(5));
        b.setLayoutParams(p);
        return b;
    }

    private void showEntry() {
        base();

        root.addView(topBar("DAMKAR TAPUT", "SISTEM INFORMASI & PENGADUAN • TAPANULI UTARA"));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(10), dp(16), 0);
        root.addView(content, new LinearLayout.LayoutParams(-1, -2));

        TextView welcome = text("Kabar & informasi terbaru", 18, 0xFF263238);
        welcome.setTypeface(null, 1);
        content.addView(welcome);

        TextView hint = text("Geser berita untuk melihat informasi Damkar Taput.", 13, 0xFF78909C);
        hint.setPadding(0, dp(5), 0, dp(10));
        content.addView(hint);

        addNewsSlider(content);

        LinearLayout emergency = new LinearLayout(this);
        emergency.setOrientation(LinearLayout.VERTICAL);
        emergency.setPadding(dp(18), dp(18), dp(18), dp(18));
        emergency.setBackground(bg(0xFFFFFFFF, 16));
        emergency.setElevation(dp(2));

        TextView et = text("Butuh bantuan Damkar?", 18, 0xFF263238);
        et.setTypeface(null, 1);
        TextView eb = text("Sampaikan lokasi dan kejadian. Anda tidak perlu membuat akun.", 13, 0xFF607D8B);
        eb.setPadding(0, dp(6), 0, dp(12));
        emergency.addView(et);
        emergency.addView(eb);

        Button report = actionButton("LAPOR KE POSKO", 0xFFC62828, Color.WHITE);
        report.setTextSize(17);
        report.setOnClickListener(v -> report());
        emergency.addView(report, new LinearLayout.LayoutParams(-1, dp(56)));

        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, -2);
        ep.setMargins(0, dp(10), 0, dp(8));
        content.addView(emergency, ep);

        TextView citizen = text("Layanan masyarakat • cepat • sederhana • langsung ke Posko", 12, 0xFF78909C);
        citizen.setGravity(Gravity.CENTER);
        citizen.setPadding(0, dp(4), 0, dp(12));
        content.addView(citizen);

        Button staff = actionButton("LOGIN PETUGAS", 0xFFFFFFFF, 0xFFC62828);
        staff.setOnClickListener(v -> loginDialog());
        content.addView(staff);

        TextView footer = text("DAMKAR TAPUT V3.0\nAplikasi masih dalam tahap pengembangan\nDikembangkan oleh Rynt Harianja • 2026", 11.5f, 0xFF90A4AE);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(dp(10), dp(18), dp(10), dp(6));
        content.addView(footer);
    }

    private void addNewsSlider(LinearLayout parent) {
        FrameLayout frame = new FrameLayout(this);
        frame.setBackground(bg(Color.WHITE, 16));
        frame.setClipChildren(true);
        frame.setElevation(dp(2));

        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(230));
        fp.setMargins(0, 0, 0, dp(12));
        parent.addView(frame, fp);

        for (int i = 0; i < NEWS_TITLE.length; i++) {
            frame.addView(makeSlide(i), new FrameLayout.LayoutParams(-1, -1));
            frame.getChildAt(i).setVisibility(i == 0 ? View.VISIBLE : View.GONE);
        }

        TextView left = text("‹", 38, Color.WHITE);
        left.setGravity(Gravity.CENTER);
        left.setBackground(bg(0x66000000, 30));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(42), dp(52), Gravity.LEFT | Gravity.CENTER_VERTICAL);
        lp.setMargins(dp(8), 0, 0, 0);
        frame.addView(left, lp);

        TextView right = text("›", 38, Color.WHITE);
        right.setGravity(Gravity.CENTER);
        right.setBackground(bg(0x66000000, 30));
        FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(dp(42), dp(52), Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        rp.setMargins(0, 0, dp(8), 0);
        frame.addView(right, rp);

        left.setOnClickListener(v -> {
            slideIndex = (slideIndex + NEWS_TITLE.length - 1) % NEWS_TITLE.length;
            showSlide(frame, slideIndex);
        });
        right.setOnClickListener(v -> {
            slideIndex = (slideIndex + 1) % NEWS_TITLE.length;
            showSlide(frame, slideIndex);
        });

        sliderHandler.postDelayed(new Runnable() {
            @Override public void run() {
                slideIndex = (slideIndex + 1) % NEWS_TITLE.length;
                showSlide(frame, slideIndex);
                sliderHandler.postDelayed(this, 5000);
            }
        }, 5000);
    }

    private View makeSlide(int i) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundColor(Color.WHITE);

        ImageView image = new ImageView(this);
        image.setImageResource(NEWS_IMAGES[i]);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        card.addView(image, new LinearLayout.LayoutParams(-1, dp(145)));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(16), dp(10), dp(60), dp(10));

        TextView title = text(NEWS_TITLE[i], 16, 0xFF263238);
        title.setTypeface(null, 1);
        TextView body = text(NEWS_BODY[i], 12.5f, 0xFF607D8B);
        body.setPadding(0, dp(4), 0, 0);

        info.addView(title);
        info.addView(body);
        card.addView(info, new LinearLayout.LayoutParams(-1, 0, 1));
        return card;
    }

    private void showSlide(FrameLayout frame, int index) {
        for (int i = 0; i < NEWS_TITLE.length; i++) {
            frame.getChildAt(i).setVisibility(i == index ? View.VISIBLE : View.GONE);
        }
    }

    private void loginDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), 0, dp(20), 0);

        Spinner role = new Spinner(this);
        String[] roles = {"Admin", "Pimpinan", "Danru", "Personil"};
        role.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, roles));
        box.addView(role);

        EditText user = new EditText(this);
        user.setHint("Username");
        box.addView(user);

        EditText pass = new EditText(this);
        pass.setHint("Password");
        pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        box.addView(pass);

        new AlertDialog.Builder(this)
                .setTitle("LOGIN PETUGAS")
                .setView(box)
                .setNegativeButton("BATAL", null)
                .setPositiveButton("LOGIN", (d, w) -> {
                    String r = roles[role.getSelectedItemPosition()];
                    String u = user.getText().toString().trim();
                    String p = pass.getText().toString();
                    if (valid(r, u, p)) {
                        pref.edit().putString("role", r).putString("nama", u).apply();
                        showStaffDashboard(r);
                    } else {
                        Toast.makeText(this, "Username atau password salah.", Toast.LENGTH_LONG).show();
                    }
                }).show();
    }

    private boolean valid(String role, String user, String pass) {
        String r = role.toLowerCase(Locale.US);
        if (r.equals("admin")) return user.equalsIgnoreCase("admin") && pass.equals("admin123");
        if (r.equals("pimpinan")) return user.equalsIgnoreCase("pimpinan") && pass.equals("pimpinan123");
        if (r.equals("danru")) return user.equalsIgnoreCase("danru") && pass.equals("danru123");
        return user.equalsIgnoreCase("personil") && pass.equals("personil123");
    }

    private void showStaffDashboard(String role) {
        base();
        root.addView(topBar("DAMKAR TAPUT", "RUANG KERJA PETUGAS"));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(10), dp(16), 0);
        root.addView(content);

        LinearLayout identity = new LinearLayout(this);
        identity.setOrientation(LinearLayout.VERTICAL);
        identity.setPadding(dp(16), dp(14), dp(16), dp(14));
        identity.setBackground(bg(0xFFFFFFFF, 16));

        TextView who = text("PETUGAS " + role.toUpperCase(Locale.US), 17, 0xFF263238);
        who.setTypeface(null, 1);
        TextView sub = text("Status dan koordinasi pelayanan Damkar Taput", 12.5f, 0xFF78909C);
        sub.setPadding(0, dp(4), 0, 0);
        identity.addView(who);
        identity.addView(sub);
        content.addView(identity);

        content.addView(sectionLabel("STATUS SAAT INI"));
        statusTv = text(statusLabel(), 16, 0xFF263238);
        statusTv.setPadding(dp(16), dp(14), dp(16), dp(14));
        statusTv.setBackground(bg(0xFFFFFFFF, 14));
        content.addView(statusTv);

        reguTv = text("REGU  •  " + pref.getString("regu", REGU[0]), 14, 0xFF455A64);
        reguTv.setPadding(dp(16), dp(12), dp(16), dp(12));
        content.addView(reguTv);

        content.addView(sectionLabel("LAYANAN"));

        Button report = actionButton("LAPOR CEPAT KE POSKO", 0xFFC62828, Color.WHITE);
        report.setOnClickListener(v -> report());
        content.addView(report);

        Button call = actionButton("HUBUNGI POSKO", 0xFFFFFFFF, 0xFFC62828);
        call.setOnClickListener(v -> callMenu());
        content.addView(call);

        Button news = actionButton("KABAR BERITA DAMKAR TAPUT", 0xFFFFFFFF, 0xFF1565C0);
        news.setOnClickListener(v -> newsDialog());
        content.addView(news);

        content.addView(sectionLabel("PERSONEL & REGU"));

        Button st = actionButton("UBAH STATUS PERSONEL", 0xFFFFFFFF, 0xFF263238);
        st.setOnClickListener(v -> statusMenu());
        content.addView(st);

        Button rg = actionButton("PILIH REGU & POS", 0xFFFFFFFF, 0xFF263238);
        rg.setOnClickListener(v -> reguMenu());
        content.addView(rg);

        if (role.equalsIgnoreCase("Admin")) {
            Button add = actionButton("KELOLA KABAR BERITA", 0xFFFFFFFF, 0xFF2E7D32);
            add.setOnClickListener(v -> addNewsDialog());
            content.addView(add);
        }

        Button logout = actionButton("KELUAR", 0xFFECEFF1, 0xFF455A64);
        logout.setOnClickListener(v -> {
            pref.edit().clear().apply();
            showEntry();
        });
        content.addView(logout);

        TextView foot = text("DAMKAR TAPUT V3.0 • Rynt Harianja • 2026", 11, 0xFF90A4AE);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, dp(18), 0, dp(8));
        content.addView(foot);
    }

    private String statusLabel() {
        String s = pref.getString("status", "SIAP");
        String icon = "●";
        int color = 0xFF2E7D32;
        if (s.equals("OTW")) { icon = "●"; color = 0xFFF9A825; }
        else if (s.equals("TIBA")) { icon = "●"; color = 0xFF1565C0; }
        else if (s.equals("OPERASI")) { icon = "●"; color = 0xFFC62828; }
        else if (s.equals("SELESAI")) { icon = "●"; color = 0xFF78909C; }
        return icon + "  STATUS PERSONEL: " + s;
    }

    private void newsDialog() {
        ArrayList<String> n = loadNews();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10), 0, dp(10), 0);
        if (n.isEmpty()) box.addView(text("Belum ada berita.", 16, 0xFF455A64));
        for (String x : n) {
            TextView item = text(x, 15, 0xFF263238);
            item.setPadding(dp(4), dp(10), dp(4), dp(10));
            box.addView(item);
        }
        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        new AlertDialog.Builder(this)
                .setTitle("KABAR BERITA DAMKAR TAPUT")
                .setView(sv)
                .setPositiveButton("TUTUP", null)
                .show();
    }

    private ArrayList<String> loadNews() {
        String raw = pref.getString("news",
                "Pelayanan dan kesiapsiagaan Damkar Tapanuli Utara terus ditingkatkan.|" +
                "Personel Damkar siap menerima laporan keadaan darurat masyarakat.|" +
                "Edukasi pencegahan kebakaran dan penggunaan APAR.");
        ArrayList<String> l = new ArrayList<>();
        for (String x : raw.split("\\|")) if (!x.trim().isEmpty()) l.add(x);
        return l;
    }

    private void addNewsDialog() {
        EditText e = new EditText(this);
        e.setHint("Judul / isi kabar berita");
        new AlertDialog.Builder(this)
                .setTitle("TAMBAH BERITA")
                .setView(e)
                .setNegativeButton("BATAL", null)
                .setPositiveButton("SIMPAN", (d, w) -> {
                    String x = e.getText().toString().trim();
                    if (x.isEmpty()) return;
                    ArrayList<String> l = loadNews();
                    l.add(0, x);
                    pref.edit().putString("news", join(l, "|")).apply();
                    Toast.makeText(this, "Berita disimpan.", Toast.LENGTH_SHORT).show();
                }).show();
    }

    private String join(ArrayList<String> a, String sep) {
        StringBuilder s = new StringBuilder();
        for (String x : a) {
            if (s.length() > 0) s.append(sep);
            s.append(x.replace("|", " "));
        }
        return s.toString();
    }

    private void dial(String n) {
        try { startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + n))); }
        catch (Exception ignored) {}
    }

    private void callMenu() {
        new AlertDialog.Builder(this)
                .setTitle("HUBUNGI POSKO")
                .setItems(new String[]{"0633 21113", "+62 852-9615-0410"},
                        (d, w) -> dial(w == 0 ? OFF : MOB))
                .show();
    }

    private void report() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), 0, dp(18), 0);

        EditText type = new EditText(this);
        type.setHint("Jenis kejadian");
        box.addView(type);

        EditText loc = new EditText(this);
        loc.setHint("Lokasi kejadian");
        box.addView(loc);

        EditText desc = new EditText(this);
        desc.setHint("Keterangan singkat");
        box.addView(desc);

        new AlertDialog.Builder(this)
                .setTitle("LAPOR KE POSKO")
                .setMessage("Isi informasi singkat. Laporan akan diteruskan ke WhatsApp Posko.")
                .setView(box)
                .setNegativeButton("BATAL", null)
                .setPositiveButton("KIRIM", (d, w) -> {
                    String m = "LAPOR CEPAT DAMKAR TAPUT\n" +
                            "Kejadian: " + type.getText() + "\n" +
                            "Lokasi: " + loc.getText() + "\n" +
                            "Keterangan: " + desc.getText();
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW,
                                Uri.parse("https://wa.me/" + MOB.substring(1) + "?text=" + Uri.encode(m))));
                    } catch (Exception z) {
                        dial(MOB);
                    }
                }).show();
    }

    private void statusMenu() {
        String[] a = {"SIAP", "OTW", "TIBA", "OPERASI", "SELESAI"};
        new AlertDialog.Builder(this)
                .setTitle("STATUS PERSONEL")
                .setItems(a, (d, w) -> {
                    pref.edit().putString("status", a[w]).apply();
                    if (statusTv != null) statusTv.setText(statusLabel());
                }).show();
    }

    private void reguMenu() {
        new AlertDialog.Builder(this)
                .setTitle("REGU & POS DAMKAR")
                .setItems(REGU, (d, w) -> {
                    pref.edit().putString("regu", REGU[w]).apply();
                    if (reguTv != null) reguTv.setText("REGU  •  " + REGU[w]);
                }).show();
    }

    @Override protected void onDestroy() {
        sliderHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
