# DAMKAR TAPUT V3.1 — Complete

Mobile Android prototype for DAMKAR TAPUT.

Included:
- Public home + Kabar Berita slider
- LAPOR KE POSKO with firefighter calling visual
- Report form
- Admin/Pimpinan/Danru/Personil login
- Kelola Kabar Berita: photo, title, description, Facebook post URL, edit/delete
- Public BACA BERITA opens the exact saved Facebook URL
- Personil Piket with SIAP/OTW/TIBA/OPERASI/SELESAI
- Chat dengan Personil Piket
- Local persistence using SharedPreferences
- WhatsApp report shortcut and phone call shortcut

Demo credentials:
admin/admin123
pimpinan/pimpinan123
danru/danru123
personil/personil123

Note: this version is local-only. For real-time chat/notifications between multiple phones, connect a backend (Firebase/Supabase/etc.) in a later phase.
