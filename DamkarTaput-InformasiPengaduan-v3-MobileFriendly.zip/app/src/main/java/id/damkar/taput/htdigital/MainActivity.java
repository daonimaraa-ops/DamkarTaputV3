package id.damkar.taput.htdigital;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final String MOB = "+6285296150410";
    private static final String OFF = "063321113";
    private SharedPreferences pref;
    private LinearLayout root;
    private TextView statusTv, reguTv;
    private Handler sliderHandler = new Handler();
    private int slideIndex = 0;

    private final String[] REGU = {
        "Regu 1 - Pos Damkar Tarutung","Regu 2 - Pos Damkar Tarutung","Regu 3 - Pos Damkar Tarutung",
        "Regu 1 - Pos Damkar Siborong-borong","Regu 2 - Pos Damkar Siborong-borong","Regu 3 - Pos Damkar Siborong-borong",
        "Regu 1 - Pos Damkar Pahae","Regu 2 - Pos Damkar Pahae","Regu 3 - Pos Damkar Pahae",
        "Regu 1 - Pos Damkar Pangaribuan","Regu 2 - Pos Damkar Pangaribuan","Regu 3 - Pos Damkar Pangaribuan"
    };

    private final String[] NEWS_TITLE = {
        "Siaga dan Pelayanan Damkar Taput",
        "Kesiapsiagaan Personel",
        "Edukasi Pencegahan Kebakaran"
    };
    private final String[] NEWS_BODY = {
        "Informasi pelayanan, kesiapsiagaan dan kegiatan Damkar Tapanuli Utara.",
        "Personel Damkar siap menerima laporan dan melaksanakan penanganan keadaan darurat.",
        "Kenali bahaya kebakaran, gunakan APAR dengan benar dan segera laporkan kejadian."
    };
    private final int[] NEWS_COLORS = {0xFFC62828,0xFF1565C0,0xFF2E7D32};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        pref = getSharedPreferences("damkar", MODE_PRIVATE);
        showEntry();
    }

    private void base() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(0,0,0,16);
        ScrollView s = new ScrollView(this); s.setFillViewport(true); s.addView(root); setContentView(s);
    }

    private TextView tv(String text, float size) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(size); t.setTextColor(0xFF263238);
        t.setPadding(16,12,16,12); return t;
    }

    private TextView header(String text) {
        TextView h=tv(text,23); h.setGravity(Gravity.CENTER); h.setTextColor(Color.WHITE); h.setTypeface(null,1);
        h.setBackgroundColor(0xFFC62828); return h;
    }

    private Button btn(String text) {
        Button b=new Button(this); b.setText(text); b.setTextSize(17); b.setAllCaps(false); b.setTextColor(0xFF263238);
        GradientDrawable bg=new GradientDrawable(); bg.setColor(0xFFF3F5F7); bg.setCornerRadius(22); bg.setStroke(1,0xFFE0E0E0); b.setBackground(bg);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,62); p.setMargins(16,5,16,5); b.setLayoutParams(p); return b;
    }

    private void showEntry() {
        base(); root.addView(header("DAMKAR TAPUT"));
        TextView sub=tv("SISTEM INFORMASI & PENGADUAN\nDAMKAR TAPANULI UTARA",16); sub.setGravity(Gravity.CENTER); sub.setTypeface(null,1); root.addView(sub);
        addNewsSlider(root);
        Button citizen=btn("🚨  LAPOR KE POSKO"); citizen.setTextSize(19); citizen.setTextColor(0xFFFFFFFF); citizen.setBackgroundColor(0xFFC62828); citizen.setOnClickListener(v->report()); root.addView(citizen);
        TextView note=tv("Masyarakat tidak perlu login. Tekan tombol LAPOR untuk menyampaikan pengaduan kepada Posko Damkar.",14); note.setGravity(Gravity.CENTER); root.addView(note);
        Space space=new Space(this); root.addView(space,new LinearLayout.LayoutParams(1,35));
        TextView footer=tv("DAMKAR TAPUT V3.0\nAplikasi ini masih dalam tahap pengembangan\nDikembangkan oleh Rynt Harianja • 2026",13); footer.setGravity(Gravity.CENTER); footer.setTextColor(0xFF78909C); root.addView(footer);
        Button staff=btn("🔐  LOGIN PETUGAS"); staff.setOnClickListener(v->loginDialog()); root.addView(staff);
    }

    private void addNewsSlider(LinearLayout parent) {
        final FrameLayout frame=new FrameLayout(this); LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,205); fp.setMargins(12,4,12,8); frame.setLayoutParams(fp);
        for(int i=0;i<NEWS_TITLE.length;i++) { TextView slide=makeSlide(i); slide.setVisibility(i==0?View.VISIBLE:View.GONE); frame.addView(slide); }
        TextView left=tv("‹",38); left.setTextColor(Color.WHITE); left.setGravity(Gravity.CENTER); left.setBackgroundColor(0x55000000); FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(55,-1,Gravity.LEFT|Gravity.CENTER_VERTICAL); frame.addView(left,lp);
        TextView right=tv("›",38); right.setTextColor(Color.WHITE); right.setGravity(Gravity.CENTER); right.setBackgroundColor(0x55000000); FrameLayout.LayoutParams rp=new FrameLayout.LayoutParams(55,-1,Gravity.RIGHT|Gravity.CENTER_VERTICAL); frame.addView(right,rp);
        left.setOnClickListener(v->{slideIndex=(slideIndex+NEWS_TITLE.length-1)%NEWS_TITLE.length; showSlide(frame,slideIndex);});
        right.setOnClickListener(v->{slideIndex=(slideIndex+1)%NEWS_TITLE.length; showSlide(frame,slideIndex);});
        parent.addView(frame);
        sliderHandler.postDelayed(new Runnable(){public void run(){slideIndex=(slideIndex+1)%NEWS_TITLE.length;showSlide(frame,slideIndex);sliderHandler.postDelayed(this,5000);}},5000);
    }

    private TextView makeSlide(int i){ TextView s=tv("📰  "+NEWS_TITLE[i]+"\n\n"+NEWS_BODY[i],17); s.setTextColor(Color.WHITE); s.setGravity(Gravity.CENTER_VERTICAL); s.setPadding(48,22,48,22); s.setBackgroundColor(NEWS_COLORS[i]); return s; }
    private void showSlide(FrameLayout frame,int index){ for(int i=0;i<NEWS_TITLE.length;i++) frame.getChildAt(i).setVisibility(i==index?View.VISIBLE:View.GONE); }

    private void loginDialog() {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(24,0,24,0);
        Spinner role=new Spinner(this); String[] roles={"Admin","Pimpinan","Danru","Personil"}; role.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,roles)); box.addView(role);
        EditText user=new EditText(this); user.setHint("Username"); box.addView(user); EditText pass=new EditText(this); pass.setHint("Password"); pass.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD); box.addView(pass);
        new AlertDialog.Builder(this).setTitle("LOGIN PETUGAS").setView(box).setNegativeButton("BATAL",null).setPositiveButton("LOGIN",(d,w)->{String r=roles[role.getSelectedItemPosition()];String u=user.getText().toString().trim();String p=pass.getText().toString();if(valid(r,u,p)){pref.edit().putString("role",r).putString("nama",u).apply();showStaffDashboard(r);}else Toast.makeText(this,"Username atau password salah.",Toast.LENGTH_LONG).show();}).show();
    }

    private boolean valid(String role,String user,String pass){String r=role.toLowerCase(Locale.US);if(r.equals("admin"))return user.equalsIgnoreCase("admin")&&pass.equals("admin123");if(r.equals("pimpinan"))return user.equalsIgnoreCase("pimpinan")&&pass.equals("pimpinan123");if(r.equals("danru"))return user.equalsIgnoreCase("danru")&&pass.equals("danru123");return user.equalsIgnoreCase("personil")&&pass.equals("personil123");}

    private void showStaffDashboard(String role) {
        base(); root.addView(header("DAMKAR TAPUT"));
        TextView who=tv("👤 "+role.toUpperCase(Locale.US)+"\nSistem internal petugas",16); who.setTypeface(null,1); root.addView(who);
        addNewsSlider(root);
        statusTv=tv(statusLabel(),19); root.addView(statusTv); reguTv=tv("👥 "+pref.getString("regu",REGU[0]),18); root.addView(reguTv);
        Button news=btn("📰  KABAR BERITA DAMKAR TAPUT"); news.setOnClickListener(v->newsDialog()); root.addView(news);
        Button report=btn("🚨  LAPOR CEPAT KE POSKO"); report.setOnClickListener(v->report()); root.addView(report);
        Button call=btn("📞  HUBUNGI POSKO"); call.setOnClickListener(v->callMenu()); root.addView(call);
        Button st=btn("🟢  STATUS PERSONEL"); st.setOnClickListener(v->statusMenu()); root.addView(st);
        Button rg=btn("👥  REGU & PERSONEL"); rg.setOnClickListener(v->reguMenu()); root.addView(rg);
        if(role.equalsIgnoreCase("Admin")){Button add=btn("✍️  KELOLA BERITA");add.setOnClickListener(v->addNewsDialog());root.addView(add);}
        Button logout=btn("↩️  KELUAR");logout.setOnClickListener(v->{pref.edit().clear().apply();showEntry();});root.addView(logout);
        TextView foot=tv("DAMKAR TAPUT V3.0 • Masih dalam tahap pengembangan • Rynt Harianja • 2026",12);foot.setGravity(Gravity.CENTER);foot.setTextColor(0xFF78909C);root.addView(foot);
    }

    private String statusLabel(){String s=pref.getString("status","SIAP");String icon="🟢";if(s.equals("OTW"))icon="🟡";else if(s.equals("TIBA"))icon="🔵";else if(s.equals("OPERASI"))icon="🔴";else if(s.equals("SELESAI"))icon="⚪";return icon+" Status personel: "+s;}

    private void newsDialog(){ArrayList<String> n=loadNews();LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);if(n.isEmpty())box.addView(tv("Belum ada berita.",17));for(String x:n)box.addView(tv("📰 "+x,16));ScrollView sv=new ScrollView(this);sv.addView(box);new AlertDialog.Builder(this).setTitle("KABAR BERITA DAMKAR TAPUT").setView(sv).setPositiveButton("TUTUP",null).show();}
    private ArrayList<String> loadNews(){String raw=pref.getString("news","Pelayanan dan kesiapsiagaan Damkar Tapanuli Utara terus ditingkatkan.|Personel Damkar siap menerima laporan keadaan darurat masyarakat.|Edukasi pencegahan kebakaran dan penggunaan APAR.");ArrayList<String> l=new ArrayList<>();for(String x:raw.split("\\|"))if(!x.trim().isEmpty())l.add(x);return l;}
    private void addNewsDialog(){EditText e=new EditText(this);e.setHint("Judul / isi kabar berita");new AlertDialog.Builder(this).setTitle("TAMBAH BERITA").setView(e).setNegativeButton("BATAL",null).setPositiveButton("SIMPAN",(d,w)->{String x=e.getText().toString().trim();if(x.isEmpty())return;ArrayList<String>l=loadNews();l.add(0,x);pref.edit().putString("news",join(l,"|")).apply();Toast.makeText(this,"Berita disimpan.",Toast.LENGTH_SHORT).show();}).show();}
    private String join(ArrayList<String>a,String sep){StringBuilder s=new StringBuilder();for(String x:a){if(s.length()>0)s.append(sep);s.append(x.replace("|"," "));}return s.toString();}

    private void dial(String n){try{startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+n)));}catch(Exception e){}}
    private void callMenu(){new AlertDialog.Builder(this).setTitle("HUBUNGI POSKO").setItems(new String[]{"☎ 0633 21113","📱 +62 852-9615-0410"},(d,w)->dial(w==0?OFF:MOB)).show();}

    private void report(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(10,0,10,0);
        EditText type=new EditText(this);type.setHint("Jenis kejadian");box.addView(type);EditText loc=new EditText(this);loc.setHint("Lokasi kejadian");box.addView(loc);EditText desc=new EditText(this);desc.setHint("Keterangan singkat");box.addView(desc);
        new AlertDialog.Builder(this).setTitle("LAPOR CEPAT KE POSKO").setMessage("Laporan akan diteruskan ke WhatsApp Posko.").setView(box).setNegativeButton("BATAL",null).setPositiveButton("KIRIM",(d,w)->{String m="🚨 LAPOR CEPAT DAMKAR TAPUT\nKejadian: "+type.getText()+"\nLokasi: "+loc.getText()+"\nKeterangan: "+desc.getText();try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/"+MOB.substring(1)+"?text="+Uri.encode(m))));}catch(Exception z){dial(MOB);}}).show();
    }

    private void statusMenu(){String[]a={"🟢 SIAP","🟡 OTW","🔵 TIBA","🔴 OPERASI","⚪ SELESAI"};new AlertDialog.Builder(this).setTitle("STATUS PERSONEL").setItems(a,(d,w)->{String v=a[w].substring(2);pref.edit().putString("status",v).apply();if(statusTv!=null)statusTv.setText(statusLabel());}).show();}
    private void reguMenu(){new AlertDialog.Builder(this).setTitle("REGU & POS DAMKAR").setItems(REGU,(d,w)->{pref.edit().putString("regu",REGU[w]).apply();if(reguTv!=null)reguTv.setText("👥 "+REGU[w]);}).show();}
}
