# DAMKAR TAPUT V3.0

Aplikasi mobile Sistem Informasi & Pengaduan Damkar Tapanuli Utara.

## Fitur
- Layar masyarakat sederhana dengan tombol **Lapor ke Posko**.
- Slider Kabar Berita Damkar Taput di bagian atas.
- Login Admin, Pimpinan, Danru, Personil.
- Status personel: SIAP, OTW, TIBA, OPERASI, SELESAI.
- Pos Damkar Tarutung, Siborong-borong, Pahae, Pangaribuan; Regu 1-3.
- Hubungi Posko: 0633 21113 / +62 852-9615-0410.
- Laporan cepat melalui WhatsApp Posko.
- Admin dapat menambahkan kabar berita secara lokal.

## Akun uji
- Admin / admin123
- Pimpinan / pimpinan123
- Danru / danru123
- Personil / personil123

## Catatan
Login dan berita pada versi ini tersimpan lokal di perangkat. Sinkronisasi multi-perangkat memerlukan backend/server pada tahap berikutnya.

**DAMKAR TAPUT V3.0**  
*Aplikasi ini masih dalam tahap pengembangan*  
**Dikembangkan oleh Rynt Harianja • 2026**
